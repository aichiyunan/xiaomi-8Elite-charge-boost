// inotify 相关常量
#[cfg(unix)]
pub const IN_MODIFY: u32 = 0x00000002;
#[cfg(unix)]
pub const IN_CLOSE_WRITE: u32 = 0x00000008;
#[cfg(unix)]
pub const IN_CREATE: u32 = 0x00000100;
#[cfg(unix)]
pub const IN_DELETE: u32 = 0x00000200;

// 文件路径常量
// [mi_charge_boost] 以下 4 个路径由“小米/红米充电加速模块”改为模块私有目录（仅改路径，逻辑未改）：
// free 由模块 WebUI 的「公版 PPS 解锁」开关映射为 1/0；disable 为占位（不会被创建，避免误删/误改本模块的 disable）；
// module.prop 为占位副本，避免改写本模块描述。
#[cfg(unix)]
pub const MODULE_BASE_PATH: &str = "/data/adb/mi_charge_boost/freepps";
pub const FREE_FILE: &str = "/data/adb/mi_charge_boost/freepps/free";
pub const DISABLE_FILE: &str = "/data/adb/mi_charge_boost/freepps/disable";
#[cfg(unix)]
pub const MODULE_PROP: &str = "/data/adb/mi_charge_boost/freepps/module.prop";
pub const PD_VERIFIED_PATH: &str = "/sys/class/qcom-battery/pd_verifed";
pub const PD_ADAPTER_VERIFIED_PATH: &str = "/sys/class/Charging_Adapter/pd_adapter/usbpd_verifed";
pub const BATTERY_STATUS_PATH: &str = "/sys/class/power_supply/battery/status";

// 金标动画广播伪造相关 sysfs 节点
#[cfg(unix)]
pub const REAL_TYPE_PATH: &str = "/sys/class/xm_power/charger/charger_common/real_type";
#[cfg(unix)]
pub const APDO_MAX_PATH: &str = "/sys/class/xm_power/typec/apdo_max";
#[cfg(unix)]
pub const ADAPTER_SVID_PATH: &str = "/sys/class/xm_power/typec/strategy_pd_auth/adapter_svid";
#[cfg(unix)]
pub const USB_VOLTAGE_NOW_PATH: &str = "/sys/class/power_supply/usb/voltage_now";
