#!/system/bin/sh
# 实时充电电流（免重启）：写 MCA charger_thermal/wired_chg_curr（单位 uA），充电中改动即时生效
# 配置 $D/cc: "<开关0|1> <电流mA>"
D=/data/adb/mi_charge_boost; mkdir -p $D
CONF=$D/cc; LOG=$D/cc.log
MIN=1000; REL=22000
# 上限跟随 DTBO 已写入的快充电流（未修改/已还原按原厂 15500）
dmax(){ S=$(getprop ro.boot.slot_suffix 2>/dev/null); x=/data/adb/mi_charge_boost/dtbo; [ -f /data/adb/.mcb_dtbo/stock.img ] && x=/data/adb/.mcb_dtbo
  i=""; [ "$(cat $x/state$S 2>/dev/null)" = mod ] && [ -f $x/conf ] && read i _r < $x/conf
  case "$i" in ''|-|*[!0-9]*) i=15500;; esac; [ $i -gt $REL ] && i=$REL; [ $i -lt $MIN ] && i=$MIN; echo $i; }
MAX=$(dmax); DEF=$MAX
node(){ for n in /sys/class/xm_power/charger/charger_thermal/wired_chg_curr \
    $(find -L /sys/class/xm_power -maxdepth 4 -name wired_chg_curr -type f 2>/dev/null); do
    [ -f "$n" ] && { echo $n; return; }; done; }
online(){ cat /sys/class/power_supply/usb/online 2>/dev/null || echo 0; }
log(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> $LOG; [ $(wc -l < $LOG) -gt 200 ] && sed -i '1,100d' $LOG; }
conf(){ EN=0; MA=$DEF; [ -f $CONF ] && read EN MA < $CONF; [ "$EN" = 1 ] || EN=0
  case "$MA" in ''|*[!0-9]*) MA=$DEF;; esac; [ $MA -lt $MIN ] && MA=$MIN; [ $MA -gt $MAX ] && MA=$MAX; }
wr(){ N=$(node); [ -n "$N" ] || return 1; chmod 0666 $N 2>/dev/null; echo $1 > $N 2>/dev/null; }
cur(){ N=$(node); [ -n "$N" ] && cat $N 2>/dev/null; }
# 自定义温控墙 $D/cc_wall: "<开关> <温度1°C> <电流1mA> <温度2°C> <电流2mA>"
wconf(){ WE=0; T1=42; C1=12000; T2=46; C2=6000; [ -f $D/cc_wall ] && read WE T1 C1 T2 C2 < $D/cc_wall; [ "$WE" = 1 ] || WE=0
  for v in T1 C1 T2 C2; do eval x=\$$v; case "$x" in ''|*[!0-9]*) WE=0;; esac; done
  for v in C1 C2; do eval x=\$$v; [ "$WE" = 1 ] && [ $x -gt $MAX ] && eval $v=$MAX; done
  [ $WE = 1 ] && [ $T2 -lt $T1 ] && { x=$T1; T1=$T2; T2=$x; x=$C1; C1=$C2; C2=$x; }; }
# 温度（0.1°C）：软断充伪装时用真实温度
temp(){ t=""; [ -f $D/soft_on ] && t=$(cat $D/real_temp 2>/dev/null); [ -n "$t" ] || t=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); echo ${t:-0}; }
# 当前应写的上限 mA（温控墙带 1°C 回差，档位记在 $D/cc_lvl）
target(){ conf; wconf; L=0; T=$MA
  if [ $WE = 1 ]; then t=$(temp); P=$(cat $D/cc_lvl 2>/dev/null || echo 0)
    if [ $t -ge $((T2*10)) ] || { [ "$P" = 2 ] && [ $t -gt $((T2*10-10)) ]; }; then L=2
    elif [ $t -ge $((T1*10)) ] || { [ "$P" -ge 1 ] && [ $t -gt $((T1*10-10)) ]; }; then L=1; fi
    [ $L = 1 ] && [ $C1 -lt $T ] && T=$C1; [ $L = 2 ] && [ $C2 -lt $T ] && T=$C2
  fi; echo $L > $D/cc_lvl; echo $T; }
apply(){ conf; [ $EN = 1 ] || return 0; wr $(($(target)*1000)); }
release(){ wr $((REL*1000)); }   # 交还系统温控：写回最大值，之后由系统按温度下发
status(){ conf; wconf; N=$(node); c=$(cur); i=$(cat /sys/class/power_supply/battery/current_now 2>/dev/null)
  echo "{\"avail\":$([ -n "$N" ] && echo 1 || echo 0),\"en\":$EN,\"ma\":$MA,\"max\":$MAX,\"cur\":\"$c\",\"ibat\":\"$i\",\"online\":$(online),\"fix\":\"$(cat $D/cc_fix 2>/dev/null)\",\"we\":$WE,\"t1\":$T1,\"c1\":$C1,\"t2\":$T2,\"c2\":$C2,\"lvl\":\"$(cat $D/cc_lvl 2>/dev/null)\",\"temp\":\"$(temp)\"}"; }
case "$1" in
  status) status;;
  set) [ "$2" = 1 ] && EN=1 || EN=0; echo "$EN ${3:-$DEF}" > $CONF; conf; echo "$EN $MA" > $CONF; echo 0 > $D/cc_fix
       if [ $EN = 1 ]; then apply; log "开启，上限 ${MA}mA（充电器在线=$(online)）"
       else release; log "关闭，交还系统温控"; fi; status;;
  wall) echo "${2:-0} ${3:-42} ${4:-12000} ${5:-46} ${6:-6000}" > $D/cc_wall; wconf; echo "$WE $T1 $C1 $T2 $C2" > $D/cc_wall
        log "温控墙$([ $WE = 1 ] && echo "开启：${T1}°C→${C1}mA，${T2}°C→${C2}mA" || echo 关闭)"; apply; status;;
  target) target;;
  apply) apply;;
  release) release;;
  log) tail -n 40 $LOG 2>/dev/null || echo 暂无;;
  *) echo "用法: cc.sh status|set 0|1 <mA>|wall 0|1 T1 C1 T2 C2|apply|release|log";;
esac
