#!/system/bin/sh
# 公版 PPS 守护：只在拔出充电器时写 pd_verifed=1；充电中不写，避免打断小米原装头的 MIPPS 认证
MODDIR=${0%/*}; P=$MODDIR/pps.sh; D=/data/adb/mi_charge_boost
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
if [ -f $D/pps.pid ] && kill -0 $(cat $D/pps.pid) 2>/dev/null; then exit 0; fi
echo $$ > $D/pps.pid
fp(){ [ -d /data/adb/modules/FreePPS ] && [ ! -f /data/adb/modules/FreePPS/disable ] && [ ! -f /data/adb/modules/FreePPS/remove ]; }
last=$(cat /sys/class/power_supply/usb/online 2>/dev/null || echo 0)
[ "$(cat $D/pps 2>/dev/null)" = 1 ] && [ "$last" != 1 ] && ! fp && sh $P unplug
while true; do
  if [ -f ${MODDIR%/pps}/disable ] || [ "$(cat $D/pps 2>/dev/null)" != 1 ] || fp; then
    last=$(cat /sys/class/power_supply/usb/online 2>/dev/null || echo 0); sleep 5; continue; fi
  on=$(cat /sys/class/power_supply/usb/online 2>/dev/null || echo 0)
  if [ "$on" = 1 ] && [ "$last" != 1 ]; then
    [ "$(cat $D/pps_gold 2>/dev/null)" = 1 ] && sh $P burst &
    (sleep 3; sh $P plug) &
  elif [ "$on" != 1 ] && [ "$last" = 1 ]; then
    sh $P unplug; sh ${MODDIR%/pps}/dtbo/apply.sh desc >/dev/null 2>&1
  fi
  last=$on
  sleep 0.5
done
