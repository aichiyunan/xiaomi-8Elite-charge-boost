#!/system/bin/sh
# 用法: apply.sh <电流mA> <关机电压mV> <断充温度°C> [165|-] | restore | status
# 第 4 项 165 = 屏幕超频 165Hz（华星 o3_42 屏添加 132/144/155/165Hz timing）
H=${0%/*}; D=${DTBO_D:-/data/adb/mi_charge_boost/dtbo}
# 数据目录必须可写：移植系统上可能出现属主/SELinux 标签不对导致 Permission denied，先修复，修不好换备用目录
okw(){ mkdir -p "$1" 2>/dev/null && touch "$1/.w" 2>/dev/null && rm -f "$1/.w"; }
F=/data/adb/.mcb_dtbo
if [ -z "$DTBO_D" ] && [ -f $F/stock.img ]; then D=$F
elif ! okw $D; then
  R=${D%/dtbo}; chattr -R -i $R 2>/dev/null; chown -R 0:0 $R 2>/dev/null; chmod -R u+rwX,go+rX $R 2>/dev/null
  chcon -R u:object_r:adb_data_file:s0 $R 2>/dev/null
  if ! okw $D; then
    if [ -z "$DTBO_D" ] && okw $F; then chcon -R u:object_r:adb_data_file:s0 $F 2>/dev/null; D=$F
    else echo "! 数据目录 $D 不可写（Permission denied）"; exit 1; fi
  fi
fi
S=$(getprop ro.boot.slot_suffix)
BLK=/dev/block/by-name/dtbo$S; [ -e $BLK ] || BLK=/dev/block/bootdevice/by-name/dtbo$S
[ -n "$DTBO_BLK" ] && BLK=$DTBO_BLK
[ -e $BLK ] || { echo "! 找不到 dtbo 分区"; exit 1; }
chmod 755 $H/dtbopatch
prep(){ # $1=I $2=T：Q: 行（按 OS3 重构的快充表）只在改了电流或温度时写入；{IQ}/{TQ} 未设定时用原厂上限 15500/48
  iq=$1; [ "$iq" = - ] && iq=15500; tq=$2; [ "$tq" = - ] && tq=48
  # 改了电流：全程按所选电流满速撑到 4580mV（与 303 加速版一致）；没改电流：高压段保持原厂 16500/3780/4510
  if [ "$1" = - ]; then mq=$iq; [ $mq -gt 16500 ] && mq=16500; lq=3780; vq=4510; mv='{I}'; else mq=$1; lq=$1; vq=4580; mv=$1; fi
  sv='{I}'; [ "$1" = - ] || { sv=$1; [ $1 -ge 20000 ] && sv=20000; }
  if [ "$1$2" = "--" ]; then grep -v '^Q:' $H/dada.tpl; else sed 's/^Q://' $H/dada.tpl; fi | sed "s/{IQ}/$iq/g; s/{TQ}/$tq/g; s/{S}/$sv/g; s/{MQ}/$mq/g; s/{LQ}/$lq/g; s/{VQ}/$vq/g; s/{M}/$mv/g"
}
sha(){ dd if="$1" bs=4096 count=$2 2>/dev/null | sha256sum | cut -d' ' -f1; }
hsha(){ # 只算 DT table 头部 total_size 长度的 sha256，与分区大小、尾部填充、AVB 尾部无关
  [ "$(head -c 4 "$1" | od -An -tx1 | tr -d ' \n')" = d7b7ab1e ] || return 1
  n=$((0x$(dd if="$1" bs=1 skip=4 count=4 2>/dev/null | od -An -tx1 | tr -d ' \n')))
  [ "$n" -gt 0 ] || return 1; head -c $n "$1" | sha256sum | cut -d' ' -f1; }
# 旧版快充表布局（OS3.0.2–3.0.303 等 HyperOS 2 底包，没有 *_volt_para*_4/_5）：
# vstep_para 格式不同保持原厂，_4/_5 表不存在不写；以下属性原厂值与新版不同，按模板整体覆盖
ALLOW='^mismatch +(mca_strategy_quick_charge/(temp_para[12]|(normal|ffc)_volt_para[12]_[23]|ffc_stage_para2_3|div_max_curr|div_single_curr)|mca_quick_charge_batt_para_gbl/.*)$'
oldtpl(){ grep -vE '^(Q:)?mca_strategy_quick_charge	(vstep_para|(normal|ffc)_volt_para[12]_[45])	'; }
os3fix(){ # 仅 OS3 旧布局：普通充电截止电压 4530→4500、quick_chg_fv_hys 80→1（与 dtbo_303充电加速 一致，避开 4530 的 vbat OVP 线）
  awk -F'\t' 'BEGIN{OFS="\t"} $1~/^(Q:)?mca_buckchg_jeita$/ && $2=="jeita_para"{gsub(/\|4530\|/,"|4500|",$5)} $1~/^(Q:)?mca_strategy_quick_charge$/ && $2=="quick_chg_fv_hys"{$5="1"} {print}'; }
dropallow(){ # 没改电流/温度时旧布局的快充分段全部保持原厂
  grep -vE '^(Q:)?(mca_strategy_quick_charge	(temp_para[12]|(normal|ffc)_volt_para[12]_[23]|ffc_stage_para2_3|div_max_curr|div_single_curr)|mca_quick_charge_batt_para_gbl	[^	]+)	'; }
isold(){ # $1=镜像：用完整模板试跑，快充表 _4 缺失即为旧布局
  prep 15500 58 > $TMP/lay.tpl; DTBO_SET=I=15500,V=2700,T=58,L=48 $H/dtbopatch "$1" $TMP/lay.tpl - 2>&1 | grep -qE '^missing +mca_strategy_quick_charge/normal_volt_para1_4$'; }
oldok(){ # $1=日志：旧布局下只有允许的属性不一致、没有缺失
  grep -qE "missing=0 " "$1" || return 1
  ! grep -E '^mismatch ' "$1" | grep -vqE "$ALLOW"; }
nb(){ echo $(( $(stat -c %s "$1") / 4096 )); }
write(){ # 文件 -> 分区并校验
  n=$(nb "$1"); [ "$n" -gt 0 ] || { echo "! 文件为空"; return 1; }; want=$(sha "$1" $n)
  blockdev --setrw $BLK 2>/dev/null
  dd if="$1" of=$BLK bs=1048576 conv=fsync 2>/dev/null; sync
  [ "$(sha $BLK $n)" = "$want" ] || { echo "! 写入校验失败"; return 1; }
  echo "$want $n" > $D/written$S
}
desc(){ # 把 dtbo 状态写进模块描述，模块列表里直接可见
  P=${H%/*}/module.prop; [ -f "$P" ] || return 0
  g(){ [ "$1" = - ] && echo 原厂 || echo "$1$2"; }
  st=$(sh $H/apply.sh status 2>/dev/null); set -- $st
  bt=$(( $(date +%s) - $(cut -d. -f1 /proc/uptime) )); wt=$(stat -c %Y $D/written$S 2>/dev/null || echo 0)
  case "$1" in
    mod) v="$(g $2 mA) / $(g $4 °C) / $(g $3 mV)"; [ "$5" = 165 ] && v="$v / 屏幕 165Hz"
         if [ "$wt" -gt "$bt" ]; then t="⏳ DTBO 已写入 $v，重启生效"; else t="✅ DTBO 已生效 $v"; fi;;
    stock) if [ "$wt" -gt "$bt" ]; then t="⏳ DTBO 已还原原版，重启生效"; else t="DTBO 原版（未修改）"; fi;;
    changed) t="⚠️ DTBO 已被还原，之前的修改已失效";;
    *) t="DTBO 未修改";;
  esac
  m=$(cat /data/adb/mi_charge_boost/shutdown_mv 2>/dev/null)
  [ -n "$m" ] && [ "$m" != 0 ] && t="$t ｜ 低电量延迟关机 ${m}mV" || t="$t ｜ 低电量延迟关机 关"
  if [ "$(cat /data/adb/mi_charge_boost/pps 2>/dev/null)" = 1 ]; then
    if [ -d /data/adb/modules/FreePPS ] && [ ! -f /data/adb/modules/FreePPS/disable ]; then t="$t ｜ ⚡ 公版PPS 让给 FreePPS"
    else l=$(cat /data/adb/mi_charge_boost/pps_last 2>/dev/null); t="$t ｜ ⚡ 公版PPS 开${l:+（上次 ${l}W 头已放行）}"; fi
  else t="$t ｜ 公版PPS 关"; fi
  sed -i "s|^description=.*|description=$t ｜ 致谢：酷安@低线阻狂魔、酷安@花橋桥（PPS 节点）、酷安@瓦力喀 / FreePPS（思路参考）|" "$P"
}
case "$1" in
desc) desc; exit 0;;
status)
  [ -f $D/conf ] && read I V T Z < $D/conf
  if [ -f $D/written$S ]; then read W N < $D/written$S
    if [ "$(sha $BLK $N)" = "$W" ]; then
      if [ -f $D/conf ] && [ "$(cat $D/state$S 2>/dev/null)" = "mod" ]; then echo "mod $I $V ${T:-58} ${Z:--}"; else echo "stock"; fi; exit 0; fi
    rm -f $D/stock.img $D/written$S $D/state$S; echo "changed $I $V ${T:-58}"; exit 0; fi
  echo "none"; exit 0;;
restore)
  [ -f $D/stock.img ] || { echo "! 没有原版备份"; exit 1; }
  write $D/stock.img || exit 1; echo stock > $D/state$S
  echo "- 已写回原版 dtbo，重启生效"; desc; exit 0;;
esac
{ read -r SI_N; read -r SI_D; read -r SI_O; read -r SI_B; } <<EOF
$(sh $H/../sysinfo.sh)
EOF
[ "$SI_D" = dada ] || { echo "! 仅支持小米15 (dada)"; exit 1; }
I=${1:--}; V=${2:--}; T=${3:--}; Z=${4:--}
case "$Z" in 165|-) ;; *) echo "! 屏幕超频参数只能是 165 或 -"; exit 1;; esac
for x in "$I" "$V" "$T"; do case "$x" in -) ;; *[!0-9]*|"") echo "! 参数错误"; exit 1;; esac; done
[ "$I$V$T$Z" = "----" ] && { echo "- 都不修改，跳过写入"; exit 0; }
echo "- 机型: $SI_N (dada)　系统: $SI_O${SI_B:+（底包 $SI_B）}"
[ "$I" = - ] || { [ $I -ge 9000 ] && [ $I -le 20500 ] || { echo "! 电流范围 9000-20500 mA"; exit 1; }; }
[ "$V" = - ] || { [ $V -ge 2400 ] && [ $V -le 3400 ] || { echo "! 关机电压范围 2400-3400 mV"; exit 1; }; }
L=-
[ "$T" = - ] || { [ $T -ge 45 ] && [ $T -le 58 ] || { echo "! 温度范围 45-58°C"; exit 1; }; L=48; [ $((T-3)) -lt 48 ] && L=$((T-3)); }
# 临时目录：优先 /dev（tmpfs，不受 /data 权限、移植系统 SELinux 影响），失败再退回数据目录
TMP=; for b in /dev /data/local/tmp $D; do t=$b/mcb_dtbo.$$; rm -rf $t; mkdir -p $t 2>/dev/null && touch $t/.w 2>/dev/null && { TMP=$t; break; }; done
[ -n "$TMP" ] || { echo "! 无法创建临时目录（/dev、/data/local/tmp、$D 都不可写）"; exit 1; }
trap 'cd /; rm -rf $TMP' EXIT; cd /
# 移植系统的 dtbo 可能没有 AVB 尾部：给每个模板配上原厂 AVB 模板（算法 NONE，只更新哈希）
for n in r chk lay; do cp $H/dada.avb $TMP/$n.avb; done
if [ ! -f $D/stock.img ]; then
  dd if=$BLK of=$TMP/cur.img bs=1048576 2>/dev/null
  HS=$(hsha $TMP/cur.img); KV=; [ -n "$HS" ] && KV=$(grep "^$HS " $H/stock.list 2>/dev/null | cut -d' ' -f2)
  U=$H/unmod_$(echo "$HS" | cut -c1-8).rules
  if [ -z "$KV" ] && [ -n "$HS" ] && [ -f "$U" ]; then
    # 已收录的“预改”dtbo（移植包自带改过的充电参数）：先还原成对应原厂值，比对通过才当作原厂备份
    cp $TMP/cur.img $D/orig_port.img 2>/dev/null
    cp $H/dada.avb $TMP/u.avb; cp "$U" $TMP/u.rules
    if $H/dtbopatch $TMP/cur.img $TMP/u.rules $TMP/un.img > $TMP/un.log 2>&1 && prep 15500 58 > $TMP/chk.tpl && DTBO_SET=I=15500,V=2700,T=58,L=48 $H/dtbopatch $TMP/un.img $TMP/chk.tpl - > $TMP/chk.log 2>&1 && grep -q "done=0 mismatch=0 missing=0" $TMP/chk.log; then
      l=$(sed -n '1s/^# *//p' "$U"); KV="${l%%：*}（预改参数已还原为 OS4.0.0.19 原厂值）"; mv $TMP/un.img $TMP/cur.img
    else echo "! 预改 dtbo 还原失败：$(grep -E 'ERROR|SUMMARY' $TMP/un.log $TMP/chk.log 2>/dev/null | tail -1)"; exit 1; fi
  fi
  if [ -n "$KV" ]; then
    cp $TMP/cur.img $D/stock.img && [ "$(sha $D/stock.img 1)" = "$(sha $TMP/cur.img 1)" ] || { echo "! 原版备份写入 $D 失败"; exit 1; }
    echo "- 哈希匹配原厂 $KV dtbo，已备份 → $D/stock.img"
  else
    mkdir -p /sdcard/Download 2>/dev/null; cp $TMP/cur.img /sdcard/Download/dtbo_当前分区.img 2>/dev/null && echo "  已导出当前分区 → /sdcard/Download/dtbo_当前分区.img，可发给作者收录"
    echo "! 当前 dtbo 哈希未收录（只认已收录的原厂 dtbo），请先刷回原厂 dtbo 或把导出的镜像发给作者收录"
    echo "  分区: $BLK  头部哈希: ${HS:-无法读取}"
    rm -rf $TMP; exit 1
  fi
else
  echo "- 已有原厂备份，沿用 $D/stock.img"
fi
: > $TMP/r.tpl
[ "$I$V$T" = "---" ] || prep $I $T >> $TMP/r.tpl
[ "$Z" = 165 ] && { cat $H/hz165.tpl >> $TMP/r.tpl; echo "- 屏幕超频：添加 132/144/155/165Hz timing"; }
FORCE=
if isold $D/stock.img && [ -s $TMP/r.tpl ]; then
  if [ "$I$T" = "--" ]; then oldtpl < $TMP/r.tpl | dropallow | os3fix > $TMP/r2.tpl; echo "- 旧版快充表布局：未改电流/温度，快充表保持原厂"
  else oldtpl < $TMP/r.tpl | os3fix > $TMP/r2.tpl; echo "- 旧版快充表布局：升流步进保持原厂，按新表覆盖快充分段"; fi
  mv $TMP/r2.tpl $TMP/r.tpl
  DTBO_SET=I=$I,V=$V,T=$T,L=$L $H/dtbopatch $D/stock.img $TMP/r.tpl - > $TMP/dry 2>&1
  oldok $TMP/dry && FORCE=-force
fi
if [ -s $TMP/r.tpl ]; then
  DTBO_SET=I=$I,V=$V,T=$T,L=$L $H/dtbopatch $D/stock.img $TMP/r.tpl $TMP/new.img $FORCE > $TMP/log 2>&1
  rc=$?; grep -E "SUMMARY|ERROR|missing " $TMP/log
  [ $rc = 4 ] && grep -q "missing  *+" $TMP/log && echo "! 没找到华星 o3_42 屏幕节点，此机型/屏幕不支持超频"
else
  cp $D/stock.img $TMP/new.img; rc=0
fi
[ $rc = 0 ] || { echo "! 生成失败，分区未改动"; rm -rf $TMP; exit 1; }
write $TMP/new.img || { rm -rf $TMP; exit 1; }
echo "$I $V $T $Z" > $D/conf; echo mod > $D/state$S
rm -rf $TMP
f(){ [ "$1" = - ] && echo 不修改 || echo "$1$2"; }
desc
zz=不超频; [ "$Z" = 165 ] && zz=165Hz
echo "- 已写入：充电电流 $(f $I mA)，关机电压 $(f $V mV)，断充温度 $(f $T °C)，屏幕 $zz，重启生效"
