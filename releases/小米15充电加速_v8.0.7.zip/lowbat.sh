#!/system/bin/sh
# 低电量延迟关机：电量锁定 2%，屏蔽系统 0% 关机和小米 30 秒关机倒计时，
# 直到电池电压连续低于设定值再关机
MODDIR=${0%/*}
. $MODDIR/common.sh
if [ -f $D/lowbat.pid ] && kill -0 $(cat $D/lowbat.pid) 2>/dev/null; then exit 0; fi
echo $$ > $D/lowbat.pid
find_ps
held=0; low=0
# 小米 shutdown_delay 节点：置 1 时系统弹出 30 秒关机倒计时
SD=""
for f in $BAT/shutdown_delay /sys/class/power_supply/bms/shutdown_delay /sys/class/qcom-battery/shutdown_delay; do [ -f $f ] && SD="$SD $f"; done
for f in $(find -L /sys/class/xm_power -maxdepth 4 -name "*shutdown_delay*" -type f 2>/dev/null); do SD="$SD $f"; done
block_sd(){ for f in $SD; do [ "$(cat $f 2>/dev/null)" = "0" ] || echo 0 > $f 2>/dev/null; done; }
release(){ [ $held = 1 ] && dumpsys battery reset >/dev/null 2>&1; held=0; low=0; }
while true; do
  MV=$(cat $D/shutdown_mv 2>/dev/null); [ -n "$MV" ] || MV=2800
  [ "$MV" -gt 0 ] 2>/dev/null && { [ "$MV" -lt 2700 ] && MV=2700; [ "$MV" -gt 3400 ] && MV=3400; }
  if [ "$MV" = "0" ] || [ -z "$BAT" ]; then release; sleep 60; find_ps; continue; fi
  cap=$(cat $BAT/capacity 2>/dev/null); st=$(cat $BAT/status 2>/dev/null)
  uv=$(cat $BAT/voltage_now 2>/dev/null); [ -n "$uv" ] || { sleep 30; continue; }
  if [ "$uv" -gt 100000 ]; then mv=$((uv/1000)); else mv=$uv; fi
  if [ "$st" = "Charging" ] || [ "$st" = "Full" ] || [ "${cap:-100}" -ge 3 ]; then
    release
    if [ "${cap:-100}" -le 5 ]; then sleep 2; elif [ "${cap:-100}" -le 10 ]; then sleep 10; else sleep 30; fi
    continue
  fi
  # 电量 ≤2% 且未充电：系统显示电量锁定在 2%
  if [ "$mv" -gt "$MV" ]; then
    low=0
    [ $held = 0 ] && { dumpsys battery set level 2 >/dev/null 2>&1; held=1; }
    block_sd
  else
    # 连续 3 次低于设定值才关机，避免瞬时负载压降误判
    low=$((low+1))
    block_sd
    if [ $low -ge 3 ]; then
      echo "$(date +%s),$mv" >> $D/shutdown.log
      sync; svc power shutdown 2>/dev/null || reboot -p
      sleep 30
    fi
  fi
  sleep 2
done
