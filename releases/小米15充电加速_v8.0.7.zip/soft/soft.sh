#!/system/bin/sh
# 免重启软断充温度：温度伪装 + 到点主动停充（思路同 opbatt）
# 配置 $D/soft: "<开关0|1> <断充温度°C>"
D=/data/adb/mi_charge_boost; mkdir -p $D
CONF=$D/soft; LOG=$D/soft.log; ST=$D/soft.state
BAT=/sys/class/power_supply/battery
FAKEV=350     # 伪装值 35.0°C（落在原厂满速温区内）
FAKE_ON=400   # 真实温度 ≥40°C 才开始伪装
FAKE_OFF=380  # 低于 38°C 撤销伪装
HYS=30        # 停充后降 3°C 恢复
log(){ echo "$(date '+%m-%d %H:%M:%S') $*" >> $LOG; [ $(wc -l < $LOG) -gt 300 ] && sed -i '1,150d' $LOG; }
fnode(){ for n in /sys/class/xm_power/fuelgauge/strategy_fg/fake_temp $(find -L /sys/class/xm_power -maxdepth 4 -name fake_temp -type f 2>/dev/null); do [ -f "$n" ] && { echo $n; return; }; done; }
snode(){ for n in /sys/class/xm_power/charger/charge_interface/input_suspend $(find -L /sys/class/xm_power -maxdepth 4 -name input_suspend -type f 2>/dev/null) $BAT/input_suspend; do [ -f "$n" ] && { echo $n; return; }; done; }
online(){ cat /sys/class/power_supply/usb/online 2>/dev/null || echo 0; }
bt(){ cat $BAT/temp 2>/dev/null; }
conf(){ EN=0; CUT=52; [ -f $CONF ] && read EN CUT < $CONF; [ "$EN" = 1 ] || EN=0
  case "$CUT" in ''|*[!0-9]*) CUT=52;; esac; [ $CUT -lt 45 ] && CUT=45; [ $CUT -gt 58 ] && CUT=58; }
# 真实温度源（0.1°C）：不受 fake_temp 影响的电池温度
src_list(){
  echo "fg:/sys/class/xm_power/fuelgauge/strategy_fg/pack_tbat"
  for z in /sys/class/thermal/thermal_zone*; do
    case "$(cat $z/type 2>/dev/null)" in *batt*|*bat_therm*|battery*|*bat-therm*) echo "tz:$z/temp";; esac
  done
}
rd_src(){ # $1=kind:path → 0.1°C
  k=${1%%:*}; p=${1#*:}; v=$(cat $p 2>/dev/null); case "$v" in ''|*[!0-9-]*) return 1;; esac
  case $k in fg) echo $((v*10));; tz) [ $v -gt 1000 ] && echo $((v/100)) || echo $((v*10));; esac
}
real(){ S=$(cat $D/soft_src 2>/dev/null); [ -n "$S" ] && rd_src "$S"; }
setfake(){ F=$(fnode); [ -n "$F" ] || return 1; U=$(cat $D/soft_unit 2>/dev/null)
  if [ "$1" = off ]; then echo -999 > $F 2>/dev/null; rm -f $D/soft_on; return 0; fi
  [ "$U" = 1 ] && echo $((FAKEV/10)) > $F 2>/dev/null || echo $FAKEV > $F 2>/dev/null; touch $D/soft_on; }
suspend(){ N=$(snode); [ -n "$N" ] || return 1; chmod 0664 $N 2>/dev/null; echo $1 > $N 2>/dev/null; }
# 探测：真实温度源、fake_temp 单位、停充节点
probe(){
  setfake off; sleep 2; b=$(bt); ok=""; : > $D/soft_src
  for s in $(src_list); do v=$(rd_src "$s") || continue; d=$((v-b)); [ $d -lt 0 ] && d=$((-d))
    [ $d -le 30 ] && { ok=$s; break; }; done
  [ -n "$ok" ] && echo "$ok" > $D/soft_src
  F=$(fnode); FK=0
  if [ -n "$F" ] && [ -n "$ok" ]; then
    for u in 10 1; do echo $u > $D/soft_unit; setfake on; sleep 3; t=$(bt); r=$(rd_src "$ok")
      d=$((t-FAKEV)); [ $d -lt 0 ] && d=$((-d)); e=$((r-FAKEV)); [ $e -lt 0 ] && e=$((-e))
      if [ $d -le 5 ]; then
        if [ $e -le 10 ] && [ $((b-FAKEV)) -gt 20 ]; then log "探测：真实温度源也被伪装覆盖，禁用温度伪装"; break; fi
        FK=1; break
      fi
    done
    setfake off
  fi
  echo $FK > $D/soft_fakeok
  N=$(snode)
  log "探测：真实温度源=${ok:-无} 伪装=$([ $FK = 1 ] && echo 可用 || echo 不可用) 单位=$(cat $D/soft_unit 2>/dev/null) 停充节点=${N:-无}"
}
status(){ conf; r=$(real); [ -n "$r" ] || r=$(bt)
  echo "{\"en\":$EN,\"cut\":$CUT,\"real\":\"$r\",\"rep\":\"$(bt)\",\"fake\":$([ -f $D/soft_on ] && echo 1 || echo 0),\"fakeok\":\"$(cat $D/soft_fakeok 2>/dev/null)\",\"src\":\"$(cat $D/soft_src 2>/dev/null)\",\"stop\":$([ -f $D/soft_stop ] && echo 1 || echo 0),\"snode\":\"$(snode)\",\"online\":$(online)}"; }
release(){ setfake off; [ -f $D/soft_stop ] && { suspend 0; rm -f $D/soft_stop; }; }
main(){
case "$1" in
  status) status;;
  set) [ "$2" = 1 ] && EN=1 || EN=0; CUT=${3:-52}; echo "$EN $CUT" > $CONF; conf; echo "$EN $CUT" > $CONF
       if [ $EN = 1 ]; then [ -f $D/soft_fakeok ] || probe; log "开启，断充温度 ${CUT}°C"; else release; log "关闭，已撤销伪装/恢复充电"; fi; status;;
  probe) probe; status;;
  release) release;;
  log) tail -n 40 $LOG 2>/dev/null || echo 暂无;;
  *) echo "用法: soft.sh status|set 0|1 <°C>|probe|release|log";;
esac
}
[ "$SOFT_LIB" = 1 ] || main "$@"
