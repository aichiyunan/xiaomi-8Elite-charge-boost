#!/system/bin/sh
# 软断充温度守护：每 3 秒按真实温度决定 伪装 / 停充 / 恢复
MODDIR=${0%/*}
SOFT_LIB=1 . $MODDIR/soft.sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
# 开机清理残留
setfake off; [ -f $D/soft_stop ] && { suspend 0; rm -f $D/soft_stop; }
n=0; flips=0; ft=0
while true; do
  sleep 3; conf
  if [ $EN != 1 ] || [ -f ${MODDIR%/soft}/disable ]; then
    { [ -f $D/soft_on ] || [ -f $D/soft_stop ]; } && { release; log "已关闭，撤销伪装/恢复充电"; }
    rm -f $D/real_temp; continue
  fi
  r=$(real)
  if [ -z "$r" ]; then
    [ -f $D/soft_on ] && { setfake off; log "真实温度读不到，撤销伪装"; }
    r=$(bt)
  fi
  echo $r > $D/real_temp
  if [ "$(online)" != 1 ]; then
    [ -f $D/soft_on ] && { setfake off; log "拔出充电器，撤销伪装"; }
    [ -f $D/soft_stop ] && { suspend 0; rm -f $D/soft_stop; }
    continue
  fi
  C=$((CUT*10))
  if [ -f $D/soft_stop ]; then
    [ $r -le $((C-HYS)) ] && { suspend 0; rm -f $D/soft_stop; log "降到 $((r/10)).$((r%10))°C，恢复充电"; }
    continue
  fi
  if [ $r -ge $C ]; then
    setfake off; suspend 1; touch $D/soft_stop
    log "真实温度 $((r/10)).$((r%10))°C ≥ ${CUT}°C，停充"
    sleep 5; i=$(cat $BAT/current_now 2>/dev/null || echo 0)
    [ "$i" -lt -300000 ] 2>/dev/null && log "! 停充节点无效（仍在充 ${i}uA），已撤销伪装，交由内核 DTBO 温度保护"
    continue
  fi
  [ "$(cat $D/soft_fakeok 2>/dev/null)" = 1 ] || continue
  now=$(cut -d. -f1 /proc/uptime)
  if [ ! -f $D/soft_on ] && [ $r -ge $FAKE_ON ]; then
    [ $((now-ft)) -gt 120 ] && { ft=$now; flips=0; }; flips=$((flips+1))
    if [ $flips -gt 5 ]; then echo 0 > $D/soft_fakeok; log "! 伪装反复开关，疑似真实温度源被覆盖，已禁用伪装"; continue; fi
    setfake on; log "真实温度 $((r/10)).$((r%10))°C，开始伪装为 $((FAKEV/10))°C 保持满速"
  elif [ -f $D/soft_on ] && [ $r -lt $FAKE_OFF ]; then
    setfake off; log "降到 $((r/10)).$((r%10))°C，撤销伪装"
  elif [ -f $D/soft_on ]; then
    n=$((n+1)); [ $n -ge 10 ] && { n=0; F=$(fnode); [ "$(cat $F 2>/dev/null)" = -999 ] && { setfake on; log "伪装被复位，补写"; }; }
  fi
done
