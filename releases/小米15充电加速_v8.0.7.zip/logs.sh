#!/system/bin/sh
# 充电调试日志：list | export <名> | del <名...>
D=/data/adb/mi_charge_boost; L=$D/logs; mkdir -p $L
OUT=/storage/emulated/0
case "$1" in
list) cur=$(cat $D/current 2>/dev/null); cur=${cur%.csv}
  ls $L 2>/dev/null | sort -rn | while read f; do n=${f%.log}
    e=$(stat -c %Y $L/$f); s=$(stat -c %s $L/$f); lv=0; [ "$n" = "$cur" ] && lv=1
    echo "$n,$e,$s,$lv"; done;;
export) n=$2; [ -f $L/$n.log ] || { echo "! 没有这个日志"; exit 1; }
  dv=$(getprop ro.product.device); fn=$(date -d @$n +%y%m%d_%H%M%S 2>/dev/null || date -r $n +%y%m%d_%H%M%S)_$dv.log
  cp $L/$n.log $OUT/$fn && chmod 0666 $OUT/$fn && echo "已导出到内置存储目录 - \"$fn\"" || echo "! 导出失败";;
del) shift; for n in "$@"; do case "$n" in *[!0-9]*) ;; *) rm -f $L/$n.log;; esac; done; echo ok;;
*) echo "用法: logs.sh list|export <名>|del <名...>";;
esac
